	<footer>
		<section>
			<div>
				<h4>Полезни линкове:</h4>

				<p>Валидатори за HTML5 и CSS3:</p>
				
				<a href="http://validator.w3.org">
					<img src="../images/footer/html5.png" alt="html5.png" width="82" height="17" />
				</a>
				<a href="http://css-validator.org"><img src="../images/footer/css3.png" alt="css3.png" width="82" height="17" /></a>
			</div>

			<div>
				<h4>Партньори:</h4>
			    <a href="https://softuni.bg"><img src="../images/footer/softuni_orange.jpg" alt="softuni.jpg" width="200" height="50" /></a>
			</div>

			<div>
				<p>&#169;2014 Web site created by "Mnementh" &trade;</p>
			</div>
		</section>
	</footer>
</body>
</html>