<section class="video">
    <header>
        <h2>
                Лекции
        </h2>			
    </header>

    <article>
        <header>
                <h3>
                        С две думи - Java
                </h3>
        </header>

        <iframe src="http://www.youtube.com/embed/yHn_uhOxZSE" width="420" height="315" allowfullscreen></iframe>
    </article>
</section>