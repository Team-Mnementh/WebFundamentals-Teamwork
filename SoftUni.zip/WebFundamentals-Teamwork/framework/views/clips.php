﻿<section class="video">
	<header>
		<h2>
			Клипове
		</h2>			
	</header>

	<article>
		<header>
			<h3>
				Група ФМИ (Фатални Мосъчни Изкривявания)
			</h3>
		</header>

		<iframe src="http://www.youtube.com/embed/oggZ90EXIJQ" width="420" height="315"allowfullscreen></iframe>

		<iframe src="http://www.youtube.com/embed/9xFuEyXIRwM" width="420" height="315"allowfullscreen></iframe>

		<iframe src="http://www.youtube.com/embed/GVC4Jxh6CZo" width="420" height="315"allowfullscreen></iframe>
	</article>

	<hr />

	<article>
		<header>
			<h3>
				Java завинаги
			</h3>
		</header>

		<iframe src="http://www.youtube.com/embed/RnqAXuLZlaE" width="420" height="315"allowfullscreen></iframe>

		<iframe src="http://www.youtube.com/embed/E3418SeWZfQ" width="420" height="315"allowfullscreen></iframe>

  		<iframe src="http://www.youtube.com/embed/HXvm76e2X1Q" width="420" height="315"allowfullscreen></iframe>
	</article>
</section>