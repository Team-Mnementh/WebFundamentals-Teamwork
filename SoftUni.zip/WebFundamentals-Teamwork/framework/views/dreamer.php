<section class="dreamer">
    <header>
        <h2>SoftUni съновник</h2>
    </header>
    
    <article>
        <p><span class="operator">switch</span> (<span class="var">$dream</span>) {</p>
            <p class="pad-1"><span class="operator">case</span> <span class="var"><span class="val">"Наков ти говори на сън"</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Добре дошъл в SoftUni"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
            <p class="pad-1"><span class="operator">case</span> <span class="val">"Наков ти говори на сън, а ти му задаваш въпроси"</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Явно си минал първо ниво"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
            <p class="pad-1"><span class="operator">case</span> <span class="val">"Водиш ожесточен спор с Наков на тема - Алгоритъм за подобрение формулата на алкохола"</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Човече, по-добре спирай да сънуваш, че нещата не отиват на добре"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
            <p class="pad-1"><span class="operator">case</span> <span class="val">"Адриана Лима те чака в барчето на университета за да и обясниш разликата между C# и JAVA"</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Ставай бързо и отивай преди да са разбрали останалите и да те преварят"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
            <p class="pad-1"><span class="operator">case</span> <span class="val">"Поредната вечер в която успя да свалиш невероятно яки мацки"</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Време е да се замислиш за по-голям хард диск"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
            <p class="pad-1"><span class="operator">case</span> <span class="val">"Зала ... тишина ... една камара хора са се втренчили в мониторите си ... от време на време дочуваш тиха псувня"</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Братле не спиш!!! На изпит си!!!"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
            <p class="pad-1"><span class="operator">case</span> <span class="val">"Караш супер яка кола по магистралата с висока скорост. Опитваш да спреш, ама педала не работи ...."</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Е кво пък толкова, ти все едно не си имал бъгове в твоя код"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
            <p class="pad-1"><span class="operator">default</span>:</p>
                <p class="pad-2"><span class="var">$result</span> = <span class="val">"Стига си спал, ами върви си напиши домашното!"</span>;</p>
                <p class="pad-2"><span class="operator">break</span>;</p>
        <p>}</p>
    </article>
</section>