<?php
include 'src/fc.php';

$fc = new Fc();
$fc->run();